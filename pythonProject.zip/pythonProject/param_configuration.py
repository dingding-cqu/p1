import itertools
from collections import namedtuple

package_num, m, n = 4, 4, 48
size_finite_field = 2**8

pattern_postion = {0:[[(0,1),(1,1)], [(0,2),(2,2)], [(0,3),(3,3)]],
                   1:[[(1,2),(2,2)], [(1,3),(3,3)], [(1,0),(0,0)]],
                   2:[[(2,3),(3,3)], [(2,0),(0,0)], [(2,1),(1,1)]],
                   3:[[(3,0),(0,0)], [(3,1),(1,1)], [(3,2),(2,2)]],
                   4:[[(0,0)], [(1,1)], [(2,2)]]}
pattern_len = [10]*3+[9]*2

#The value of the diagonal element, the index of the coupling coefficient, the index of the pattern
Node = namedtuple('Node', ['val_diag', 'idx_cpl', 'idx_ptt'])
domain_val_diag = [i for i in range(size_finite_field)]
# domain_cpl = [(i,j,k) for (i,j,k) in itertools.product([i for i in range(1, size_finite_field, 1)],[i for i in range(1, size_finite_field, 1)],[i for i in range(1, size_finite_field, 1)]) ]

domain_cpl = [(i,j,k) for (i,j,k) in itertools.combinations([i for i in range(1, size_finite_field, 1)],m-1) ]
domain_idx_cpl = [i for i in range(len(domain_cpl))]

print_log = True
save_log = True
log_file_path = ""