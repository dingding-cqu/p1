from param_configuration import domain_cpl, pattern_postion, package_num, m, Node
# import galois
import numpy as np
from enum import Enum
import sympy as sy


class fullrank_decision_type(Enum):
    by_sp = 0
    by_mp = 1
    by_gpu = 2

def get_fsb_val(PA):
    pass


def backtrack_search(PA):
    pass


def search_by_jump(PA):
    pass


def print_nodes(node_list):
    for node in node_list:
        print(f'Node({node.val_diag}, {node.idx_cpl}, {node.idx_ptt})')
    print('-' * 10)


def print_matrix(matrix):
    # if matrix is None:
    #     print(matrix)
    #     return
    row_len, col_len = matrix.shape
    for i in range(row_len):
        for j in range(col_len):
            print(matrix[i, j], end=", ")
            if (j+1) % package_num == 0:
                print(" ", end="  ")
        print()
        if (i+1) % package_num == 0:
            print()


def is_fullrank(matrix_list, decsion_type=fullrank_decision_type.by_sp):
    decision_res = False
    if decsion_type == fullrank_decision_type.by_sp:
        decision_res = is_fullrank_sp(matrix_list)
    elif decsion_type == fullrank_decision_type.by_mp:
        decision_res = is_fullrank_mp(matrix_list)
    elif decsion_type == fullrank_decision_type.by_gpu:
        decision_res = is_fullrank_gpu(matrix_list)
    return decision_res


def is_fullrank_mp(matrix_list):
    pass


def is_fullrank_sp(matix_list):
    pass


def is_fullrank_gpu(matrix_list):
    pass


def combine_matrix(matrix_list, app_matrix):
    # or use [np.hstack(mat, app_matrix) for mat in matrix_list]
    return [np.concatenate((mat, app_matrix), axis=1) for mat in matrix_list]


def recover_matrix(PA):
    # 1. build matrix
    PA_len = len(PA)
    vals_diag, val_cpls, ptts_pos = [0] * len(PA), [None] * len(PA), [None] * len(PA)
    for i, node in enumerate(PA):
        vals_diag[i], val_cpls[i], ptts_pos[i] = node.val_diag, domain_cpl[node.idx_cpl], pattern_postion[node.idx_ptt]
    matrix = [[val ** i for val in vals_diag] for i in range(m)]
    pkg_matrix = sy.zeros(m*package_num, PA_len*package_num)
        # np.empty([m*package_num, PA_len*package_num])

    # 2. extend to the matrix of package form
    for j in range(PA_len):
        for i in range(m):
            fillin_mat = sy.eye(package_num) * matrix[i][j]
            if i != 0:
                # 3. add coupling coefficient
                for pos_row, pos_col in ptts_pos[j][i-1]:
                    fillin_mat[pos_row, pos_col] += val_cpls[j][i - 1]
            pkg_matrix[i * package_num:(i + 1) * package_num, j * package_num:(j + 1) * package_num] = fillin_mat
    return pkg_matrix

def recover_unkonwn_matrix(PA, app_PA):
    # 1. build matrix
    PA_len = len(PA) + 1
    vals_diag, val_cpls, ptts_pos = [0] * PA_len, [None] * PA_len, [None] * PA_len
    for i, node in enumerate(PA):
        vals_diag[i], val_cpls[i], ptts_pos[i] = node.val_diag, domain_cpl[node.idx_cpl], pattern_postion[node.idx_ptt]
    vals_diag[len(PA)], val_cpls[len(PA)], ptts_pos[len(PA)] = app_PA[0], app_PA[1], pattern_postion[app_PA[2]]

    matrix = [[val ** i for val in vals_diag] for i in range(m)]
    pkg_matrix = sy.zeros(m*package_num, PA_len*package_num)
    # np.empty([m*package_num, PA_len*package_num])

    # 2. extend to the matrix of package form
    for j in range(PA_len):
        for i in range(m):
            fillin_mat = sy.eye(package_num) * matrix[i][j]
            if i != 0:
                # 3. add coupling coefficient
                for pos_row, pos_col in ptts_pos[j][i-1]:
                    fillin_mat[pos_row, pos_col] += val_cpls[j][i - 1]
            pkg_matrix[i * package_num:(i + 1) * package_num, j * package_num:(j + 1) * package_num] = fillin_mat
    return pkg_matrix


def gauss(matrix):
    row_size, col_size = matrix.shape
    assert row_size == col_size
    a = matrix[:,:]
    for i in range(row_size-1):
        if not a[i, i]:
            for j in range(i+1, row_size, 1):
                if a[j, i]:
                    tmp = a[i,:]
                    a[i,:] = a[j,:]
                    a[j, :] = tmp
                    break
        if not a[i,i]:
            return a

        for j in range(i + 1, row_size):
            t = a[j,i]/a[i,i]
            a[j,i:] -= t*a[i,i:]
    return a

if __name__ == '__main__':
    # vals = sy.symbols('x:5')

    PA = [Node(i+1, 0, i) for i in range(3)]
    a, b, c = sy.symbols('a b c')
    # app_PA = [4, (a,b,c), 3]
    # mat = recover_unkonwn_matrix(PA, app_PA)
    # print_matrix(mat)
    # print('-'*20)
    # elim_mat = gauss(mat)
    # print_matrix(elim_mat)

# A formulaic simplification, refer to: https://blog.csdn.net/shuangguo121/article/details/86611948
    f0 = 61/3 - 76*a/21
    f1 = -3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)
    f2 = c - (113/45 - 25*(-272*a/15 - 13/15)/(9*(61/3 - 76*a/21)))*(-3*b/5 - (44/5 - 29*a/5)*(-b/7 - 22/9)/(61/3 - 76*a/21) - 134/15)/(-3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)) - 25*(44/5 - 29*a/5)/(9*(61/3 - 76*a/21)) + 206/15
    f3 = 3320*a/(21*(61/3 - 76*a/21)) - (422/15 - 40*(-272*a/15 - 13/15)/(3*(61/3 - 76*a/21)))*(83*a*(-b/7 - 22/9)/(7*(61/3 - 76*a/21)) + 11*b/7)/(-3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)) - (2075*a/(63*(61/3 - 76*a/21)) + c - (113/45 - 25*(-272*a/15 - 13/15)/(9*(61/3 - 76*a/21)))*(83*a*(-b/7 - 22/9)/(7*(61/3 - 76*a/21)) + 11*b/7)/(-3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)))*(-40*(44/5 - 29*a/5)/(3*(61/3 - 76*a/21)) - (422/15 - 40*(-272*a/15 - 13/15)/(3*(61/3 - 76*a/21)))*(-3*b/5 - (44/5 - 29*a/5)*(-b/7 - 22/9)/(61/3 - 76*a/21) - 134/15)/(-3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)) + 44/5)/(c - (113/45 - 25*(-272*a/15 - 13/15)/(9*(61/3 - 76*a/21)))*(-3*b/5 - (44/5 - 29*a/5)*(-b/7 - 22/9)/(61/3 - 76*a/21) - 134/15)/(-3*b/5 + 118/45 - (-272*a/15 - 13/15)*(-b/7 - 22/9)/(61/3 - 76*a/21)) - 25*(44/5 - 29*a/5)/(9*(61/3 - 76*a/21)) + 206/15) + 48
    print(sy.factor(f0))
    print(sy.factor(f1))
    print(sy.factor(f2))
    print(sy.factor(f3))