clc;
clear all;
n = 4; 
%��nȡֵwΪ��4��8֮���ż��ʱ���㷨�޷��õ����Ž�
% �㷨��Ϊ������4ʱ����ִ��2��,ż��Ϊ8ʱ��Ҫִ��4��
A=magic(n);
disp('Input matrix:');
disp(A);
step = 1;
while max(max(A)) > 0
    [A, subtract_mat] = greed_n_steps( A );
    if length(A) ~= n
        disp(['Error at step ', num2str(step)]);
        break;
    end
    disp(['The matrix at step ' , num2str(step)]);
    step = step + 1;
    disp('The subtraction matrix:');
    disp(subtract_mat);
    disp('The output matrix:');
    disp(A);
    if max(max(subtract_mat)) == 0
        break;
    end
end
if max(max(A)) == 0
    disp(['Congratulation, we need ', num2str(step-1), ' steps']);
else
    disp('Sorry, we cannot completely decompose this matrix, the residual matrix');
    disp(A);
end

% m =[    8     1     6
%      3     5     7
%      4     9     2];
%     
% m_step1 = [    8-7,     1-1     6-4;
%              3-1,     5-4,     7-7;
%              4-4,     9-7,     2-1];
%     
% m_step1_res = [1-1,     0,     2-2;
%                  2-2,     1-1,     0;
%                  0,     2-2,     1-1];     