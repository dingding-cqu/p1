function [ ret_matrix, subtract_mat ] = greed_n_steps( matrix )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%     is_sucess = true;
    n = length(matrix);
    subtract_mat = zeros(n);
    copy_matrix = matrix;
    for i = 1:n
       if max(max(copy_matrix)) > 0
           [ M,I ] = get_max_idx(copy_matrix);% max(copy_matrix,[],2);
%            disp(M);
%            disp(I);
           for j = 1:n
               if I(j) ~=0 
                   copy_matrix(j, I(j)) = -1*i;
                   subtract_mat(j, I(j)) = min(M);
               end
           end
       else
           break;
       end
    end
    ret_matrix = matrix - subtract_mat;
end

