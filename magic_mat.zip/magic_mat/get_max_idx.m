function [ M,I ] = get_max_idx( matrix)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    n = length(matrix);
    M = zeros(1,n);
    I = zeros(1,n);
%     disp(matrix);
    copy_matrix = matrix;
    for i = 1: n
        max_val = max(max(copy_matrix));
        if max_val <= 0
            break
        end
        [row_id, col_id] = find(copy_matrix==max_val);
        if length(row_id) ~= 1
%             disp([ num2str(length(row_id)), ' elements with value ', num2str(max_val) , ' were found in the matrix']);       
            row_id = row_id(1);
            col_id = col_id(1); 
        end
        M(row_id) = max_val;
        I(row_id) = col_id;
        copy_matrix(row_id, :) = -100*ones(1,n);
        copy_matrix(:, col_id) = -100*ones(1,n);
    end
end

